# Prépathèque
Site statique (HTML/CSS/JS) pour partager annales, cours, livres et séries d'exercices de classes préparatoires.
Déposez les PDF dans `docs/` avec le nom `Filiere_Matiere_Source_Annee_Type.pdf` ; l'action GitHub régénère `data/documents.json`.
En local : `python generate_index.py` puis `python -m http.server`. Publication : Settings > Pages > branche main, dossier root.
